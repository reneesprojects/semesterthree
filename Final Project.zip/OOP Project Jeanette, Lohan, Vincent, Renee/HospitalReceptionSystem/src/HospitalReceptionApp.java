import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import views.AdmitPatient;
import views.InsuranceClaimForm;
import views.MedicalReportForm;
import views.PatientRegistrationForm;

public class HospitalReceptionApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create buttons for different functionalities
        Button registerPatientButton = new Button("Register Patient");
        Button admitPatientButton = new Button("Admit Patient");
        Button fileInsuranceClaimButton = new Button("File Insurance Claim");
        Button fileMedicalReportButton = new Button("File Medical Report");

        // Set up actions for each button
        registerPatientButton.setOnAction(e -> openPatientRegistrationForm());
        admitPatientButton.setOnAction(e -> {
            AdmitPatient admitPatient = new AdmitPatient();
            admitPatient.start(new Stage()); // Opens the Admit Patient form
        });
        fileInsuranceClaimButton.setOnAction(e -> {
            InsuranceClaimForm insuranceForm = new InsuranceClaimForm();
            insuranceForm.display(); // Opens the Insurance Claim form
        });
        fileMedicalReportButton.setOnAction(e -> {
            MedicalReportForm medicalReportForm = new MedicalReportForm();
            medicalReportForm.display(); // Opens the Medical Report form
        });

        // Create and style layout with white background
        VBox layout = new VBox(15); // 15px spacing between buttons
        layout.setAlignment(Pos.CENTER);  // Center the buttons
        layout.setStyle("-fx-background-color: #FFFFFF; -fx-padding: 20;"); // White background with padding

        // Add buttons to the layout
        layout.getChildren().addAll(
                registerPatientButton,
                admitPatientButton,
                fileInsuranceClaimButton,
                fileMedicalReportButton
        );

        // Style the buttons
        styleButton(registerPatientButton);
        styleButton(admitPatientButton);
        styleButton(fileInsuranceClaimButton);
        styleButton(fileMedicalReportButton);

        // Set up the scene and stage
        Scene scene = new Scene(layout, 400, 350);  // Adjusted width and height for better appearance
        primaryStage.setScene(scene);
        primaryStage.setTitle("Hospital Reception System");
        primaryStage.show();
    }

    // Helper method to open the PatientRegistrationForm
    private void openPatientRegistrationForm() {
        PatientRegistrationForm registrationForm = new PatientRegistrationForm();
        Stage stage = new Stage();  // New Stage for the Patient Registration form
        registrationForm.display();  // Opens the Patient Registration form
    }

    // Helper method to style buttons with a modern look
    private void styleButton(Button button) {
        button.setStyle(
            "-fx-font-size: 14px; " +                  // Set font size
            "-fx-font-weight: bold; " +                // Set font weight to bold
            "-fx-padding: 10px 20px; " +               // Padding inside the button
            "-fx-background-color: white; " +          // White background
            "-fx-text-fill: #333333; " +               // Dark text color for readability
            "-fx-border-radius: 15px; " +              // Rounded corners
            "-fx-border-color: #4CAF50; " +            // Green border color
            "-fx-border-width: 2px;"                   // Border width
        );

        // Button hover effect: Change border color on hover
        button.setOnMouseEntered(e -> button.setStyle(
            "-fx-font-size: 14px; " + 
            "-fx-font-weight: bold; " +
            "-fx-padding: 10px 20px; " + 
            "-fx-background-color: white; " +
            "-fx-text-fill: #333333; " +
            "-fx-border-radius: 15px; " + 
            "-fx-border-color: #45a049; " +            // Darker green border color on hover
            "-fx-border-width: 2px;"
        ));

        // Reset hover effect when mouse leaves the button
        button.setOnMouseExited(e -> button.setStyle(
            "-fx-font-size: 14px; " +
            "-fx-font-weight: bold; " +
            "-fx-padding: 10px 20px; " +
            "-fx-background-color: white; " +
            "-fx-text-fill: #333333; " +
            "-fx-border-radius: 15px; " +
            "-fx-border-color: #4CAF50; " +            // Green border color
            "-fx-border-width: 2px;"
        ));
    }

    public static void main(String[] args) {
        launch(args);
    }
}



