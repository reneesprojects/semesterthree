package views;
 
import controllers.InsuranceClaimController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import models.InsuranceClaim;
 
public class InsuranceClaimForm {
 
    private TableView<InsuranceClaim> tableView;
    private TextField patientIdField;
    private TextField claimAmountField;
    private DatePicker claimDatePicker;
    private TextField descriptionField;
    private TextField statusField;
    private InsuranceClaim selectedClaim;
 
    public void display() {
        Stage stage = new Stage();
        stage.setTitle("Insurance Claim");
 
        patientIdField = new TextField();
        claimAmountField = new TextField();
        claimDatePicker = new DatePicker();
        descriptionField = new TextField();
        statusField = new TextField();
 
        Button submitButton = new Button("Submit Claim");
        submitButton.setOnAction(event -> handleSubmit());
 
        Button editButton = new Button("Edit Claim");
        editButton.setOnAction(event -> handleEdit());
 
        Button deleteButton = new Button("Delete Claim");
        deleteButton.setOnAction(event -> handleDelete());
 
        GridPane formGrid = new GridPane();
        formGrid.setPadding(new Insets(10));
        formGrid.setHgap(10);
        formGrid.setVgap(10);
        formGrid.add(new Label("Patient ID:"), 0, 0);
        formGrid.add(patientIdField, 1, 0);
        formGrid.add(new Label("Claim Amount:"), 0, 1);
        formGrid.add(claimAmountField, 1, 1);
        formGrid.add(new Label("Claim Date:"), 0, 2);
        formGrid.add(claimDatePicker, 1, 2);
        formGrid.add(new Label("Description:"), 0, 3);
        formGrid.add(descriptionField, 1, 3);
        formGrid.add(new Label("Status:"), 0, 4);
        formGrid.add(statusField, 1, 4);
        formGrid.add(submitButton, 0, 5);
        formGrid.add(editButton, 1, 5);
        formGrid.add(deleteButton, 2, 5);
 
        tableView = new TableView<>();
        TableColumn<InsuranceClaim, Integer> patientIdColumn = new TableColumn<>("Patient ID");
        patientIdColumn.setCellValueFactory(cellData -> cellData.getValue().patientIdProperty().asObject());
 
        TableColumn<InsuranceClaim, Double> claimAmountColumn = new TableColumn<>("Claim Amount");
        claimAmountColumn.setCellValueFactory(cellData -> cellData.getValue().claimAmountProperty().asObject());
 
        TableColumn<InsuranceClaim, String> claimDateColumn = new TableColumn<>("Claim Date");
        claimDateColumn.setCellValueFactory(cellData -> cellData.getValue().claimDateProperty());
 
        TableColumn<InsuranceClaim, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());
 
        TableColumn<InsuranceClaim, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(cellData -> cellData.getValue().statusProperty());
 
        tableView.getColumns().addAll(patientIdColumn, claimAmountColumn, claimDateColumn, descriptionColumn, statusColumn);
        loadInsuranceClaims();
 
        // Handle row selection to populate fields for editing
        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedClaim = newSelection;
                patientIdField.setText(String.valueOf(selectedClaim.getPatientId()));
                claimAmountField.setText(String.valueOf(selectedClaim.getClaimAmount()));
                claimDatePicker.setValue(java.time.LocalDate.parse(selectedClaim.getClaimDate()));
                descriptionField.setText(selectedClaim.getDescription());
                statusField.setText(selectedClaim.getStatus());
            }
        });
 
        VBox layout = new VBox(10, formGrid, tableView);
        layout.setPadding(new Insets(10));
 
        Scene scene = new Scene(layout, 700, 450);
        stage.setScene(scene);
        stage.show();
    }
 
    private void loadInsuranceClaims() {
        InsuranceClaimController controller = new InsuranceClaimController();
        ObservableList<InsuranceClaim> claims = FXCollections.observableArrayList(controller.getAllInsuranceClaims());
        tableView.setItems(claims);
    }
 
    private void handleSubmit() {
        try {
            int patientId = Integer.parseInt(patientIdField.getText());
            double claimAmount = Double.parseDouble(claimAmountField.getText());
            String claimDate = claimDatePicker.getValue().toString();
            String description = descriptionField.getText();
            String status = statusField.getText();
 
            InsuranceClaim claim = new InsuranceClaim(patientId, claimAmount, claimDate, description, status);
            InsuranceClaimController controller = new InsuranceClaimController();
            boolean success = controller.submitInsuranceClaim(claim);
 
            if (success) {
                System.out.println("Insurance claim submitted successfully!");
                loadInsuranceClaims();
                clearFields();
            } else {
                System.out.println("Failed to submit insurance claim.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numeric values where necessary.");
        }
    }
 
    private void handleEdit() {
        if (selectedClaim != null) {
            try {
                int patientId = Integer.parseInt(patientIdField.getText());
                double claimAmount = Double.parseDouble(claimAmountField.getText());
                String claimDate = claimDatePicker.getValue().toString();
                String description = descriptionField.getText();
                String status = statusField.getText();
 
                InsuranceClaimController controller = new InsuranceClaimController();
                boolean success = controller.updateInsuranceClaim(patientId, claimAmount, claimDate, description, status, selectedClaim.getId());
 
                if (success) {
                    System.out.println("Insurance claim updated successfully!");
                    loadInsuranceClaims();
                    clearFields();
                } else {
                    System.out.println("Failed to update insurance claim.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter numeric values where necessary.");
            }
        } else {
            System.out.println("Please select a claim to edit.");
        }
    }
 
    private void handleDelete() {
        if (selectedClaim != null) {
            InsuranceClaimController controller = new InsuranceClaimController();
            boolean success = controller.deleteInsuranceClaim(selectedClaim.getId());
 
            if (success) {
                System.out.println("Insurance claim deleted successfully!");
                loadInsuranceClaims();
                clearFields();
            } else {
                System.out.println("Failed to delete insurance claim.");
            }
        } else {
            System.out.println("Please select a claim to delete.");
        }
    }
 
    private void clearFields() {
        patientIdField.clear();
        claimAmountField.clear();
        claimDatePicker.setValue(null);
        descriptionField.clear();
        statusField.clear();
        selectedClaim = null;
    }
}