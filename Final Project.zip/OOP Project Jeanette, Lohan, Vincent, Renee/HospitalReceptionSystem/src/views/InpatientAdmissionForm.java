package views;

import controllers.AdmissionController;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import models.Patient;

public class InpatientAdmissionForm {

    private Patient patient;

    // Constructor to initialize with the selected Patient object
    public InpatientAdmissionForm(Patient patient) {
        this.patient = patient;
    }

    public void display() {
        Stage stage = new Stage();
        stage.setTitle("Inpatient Admission for " + patient.getName());

        // Pre-fill patient ID and make it read-only
        TextField patientIdField = new TextField(String.valueOf(patient.getId()));
        patientIdField.setEditable(false);

        TextField roomIdField = new TextField();
        TextField dateField = new TextField();

        Button admitButton = new Button("Admit Inpatient");
        admitButton.setOnAction(event -> {
            int roomId = Integer.parseInt(roomIdField.getText());
            String date = dateField.getText();

            // Use the patient's ID directly from the object
            boolean success = new AdmissionController().admitPatient(patient.getId(), "Inpatient", roomId, date);
            if (success) {
                System.out.println("Inpatient admitted successfully!");
                stage.close();
            } else {
                System.out.println("Failed to admit inpatient.");
            }
        });

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Patient ID:"), 0, 0);
        grid.add(patientIdField, 1, 0);
        grid.add(new Label("Room ID:"), 0, 1);
        grid.add(roomIdField, 1, 1);
        grid.add(new Label("Date (YYYY-MM-DD):"), 0, 2);
        grid.add(dateField, 1, 2);
        grid.add(admitButton, 1, 3);

        Scene scene = new Scene(grid, 300, 250);
        stage.setScene(scene);
        stage.show();
    }
}
