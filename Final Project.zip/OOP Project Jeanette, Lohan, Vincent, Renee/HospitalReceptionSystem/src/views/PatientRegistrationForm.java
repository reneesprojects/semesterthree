package views;

import controllers.PatientController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import models.Patient;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class PatientRegistrationForm {

    private TableView<Patient> tableView;
    private ObservableList<Patient> patientData;
    private PatientController patientController = new PatientController();

    public void display() {
        Stage stage = new Stage();
        stage.setTitle("Patient Registration");

        GridPane formGrid = new GridPane();
        formGrid.setPadding(new Insets(10));
        formGrid.setHgap(10);
        formGrid.setVgap(10);

        // Initialize input fields
        TextField nameField = new TextField();
        nameField.setPromptText("Enter name");

        TextField ageField = new TextField();
        ageField.setPromptText("Enter age");

        TextField genderField = new TextField();
        genderField.setPromptText("Enter gender");

        TextField contactNumberField = new TextField();
        contactNumberField.setPromptText("Enter contact number");

        TextField addressField = new TextField();
        addressField.setPromptText("Enter address");

        // Initialize action buttons
        Button addButton = new Button("Add Patient");
        Button editButton = new Button("Edit Patient");
        Button viewButton = new Button("View Patient");
        Button deleteButton = new Button("Delete Patient");
        Button scheduleAppointmentButton = new Button("Schedule Appointment");
        Button scheduleAdmissionButton = new Button("Schedule Admission");

        // Add Patient
        addButton.setOnAction(e -> {
            try {
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                String gender = genderField.getText();
                String contactNumber = contactNumberField.getText();
                String address = addressField.getText();

                Patient patient = new Patient(0, name, age, gender, contactNumber, address);
                patientController.registerPatient(patient);

                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Patient added successfully!");
                alert.showAndWait();
                refreshTable();
            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid age input.");
                alert.showAndWait();
            }
        });

        // Edit Patient
        editButton.setOnAction(e -> {
            Patient selectedPatient = tableView.getSelectionModel().getSelectedItem();
            if (selectedPatient != null) {
                selectedPatient.setName(nameField.getText());
                selectedPatient.setAge(Integer.parseInt(ageField.getText()));
                selectedPatient.setGender(genderField.getText());
                selectedPatient.setContactNumber(contactNumberField.getText());
                selectedPatient.setAddress(addressField.getText());

                patientController.updatePatient(selectedPatient);
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Patient details updated successfully!");
                alert.showAndWait();
                refreshTable();
            } else {
                new Alert(Alert.AlertType.WARNING, "Please select a patient to edit.").showAndWait();
            }
        });

        // View Patient
        viewButton.setOnAction(e -> {
            Patient selectedPatient = tableView.getSelectionModel().getSelectedItem();
            if (selectedPatient != null) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Patient Details");
                alert.setHeaderText("Details of Patient ID: " + selectedPatient.getId());
                alert.setContentText(
                        "Name: " + selectedPatient.getName() + "\n" +
                        "Age: " + selectedPatient.getAge() + "\n" +
                        "Gender: " + selectedPatient.getGender() + "\n" +
                        "Contact Number: " + selectedPatient.getContactNumber() + "\n" +
                        "Address: " + selectedPatient.getAddress()
                );
                alert.showAndWait();
            } else {
                new Alert(Alert.AlertType.WARNING, "Please select a patient to view.").showAndWait();
            }
        });

        // Delete Patient
        deleteButton.setOnAction(e -> {
            Patient selectedPatient = tableView.getSelectionModel().getSelectedItem();
            if (selectedPatient != null) {
                boolean success = patientController.deletePatient(selectedPatient.getId());
                if (success) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Patient deleted successfully!");
                    alert.showAndWait();
                    refreshTable();
                } else {
                    new Alert(Alert.AlertType.ERROR, "Failed to delete patient.").showAndWait();
                }
            } else {
                new Alert(Alert.AlertType.WARNING, "Please select a patient to delete.").showAndWait();
            }
        });

        // Schedule Appointment
        scheduleAppointmentButton.setOnAction(e -> {
            Patient selectedPatient = tableView.getSelectionModel().getSelectedItem();
            if (selectedPatient != null) {
                scheduleDialog(selectedPatient.getId(), "Schedule Appointment", true);
            } else {
                new Alert(Alert.AlertType.WARNING, "Please select a patient to schedule an appointment.").showAndWait();
            }
        });

        // Schedule Admission
        scheduleAdmissionButton.setOnAction(e -> {
            Patient selectedPatient = tableView.getSelectionModel().getSelectedItem();
            if (selectedPatient != null) {
                scheduleDialog(selectedPatient.getId(), "Schedule Admission", false);
            } else {
                new Alert(Alert.AlertType.WARNING, "Please select a patient to schedule an admission.").showAndWait();
            }
        });

        // Set up table view and columns
        tableView = new TableView<>();
        TableColumn<Patient, Number> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty());

        TableColumn<Patient, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

        TableColumn<Patient, Number> ageColumn = new TableColumn<>("Age");
        ageColumn.setCellValueFactory(cellData -> cellData.getValue().ageProperty());

        TableColumn<Patient, String> genderColumn = new TableColumn<>("Gender");
        genderColumn.setCellValueFactory(cellData -> cellData.getValue().genderProperty());

        TableColumn<Patient, String> contactNumberColumn = new TableColumn<>("Contact Number");
        contactNumberColumn.setCellValueFactory(cellData -> cellData.getValue().contactNumberProperty());

        TableColumn<Patient, String> addressColumn = new TableColumn<>("Address");
        addressColumn.setCellValueFactory(cellData -> cellData.getValue().addressProperty());

        tableView.getColumns().addAll(idColumn, nameColumn, ageColumn, genderColumn, contactNumberColumn, addressColumn);

        patientData = FXCollections.observableArrayList(patientController.getAllPatients());
        tableView.setItems(patientData);

        formGrid.add(new Label("Name:"), 0, 0);
        formGrid.add(nameField, 1, 0);
        formGrid.add(new Label("Age:"), 0, 1);
        formGrid.add(ageField, 1, 1);
        formGrid.add(new Label("Gender:"), 0, 2);
        formGrid.add(genderField, 1, 2);
        formGrid.add(new Label("Contact Number:"), 0, 3);
        formGrid.add(contactNumberField, 1, 3);
        formGrid.add(new Label("Address:"), 0, 4);
        formGrid.add(addressField, 1, 4);

        HBox buttonBox = new HBox(10, addButton, editButton, viewButton, deleteButton, scheduleAppointmentButton, scheduleAdmissionButton);

        VBox layout = new VBox(10, formGrid, buttonBox, tableView);
        layout.setPadding(new Insets(10));

        Scene scene = new Scene(layout, 850, 700);
        stage.setScene(scene);
        stage.show();
    }

    private void scheduleDialog(int patientId, String title, boolean isAppointment) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(title);

        VBox dialogPane = new VBox(10);
        DatePicker datePicker = new DatePicker();
        ComboBox<String> timeComboBox = new ComboBox<>();
        for (int hour = 8; hour <= 17; hour++) {
            timeComboBox.getItems().add(String.format("%02d:00", hour));
            timeComboBox.getItems().add(String.format("%02d:30", hour));
        }
        TextField reasonField = new TextField();
        reasonField.setPromptText(isAppointment ? "Appointment Reason" : "Admission Reason");

        dialogPane.getChildren().addAll(new Label("Select Date:"), datePicker, new Label("Select Time:"), timeComboBox, new Label("Reason:"), reasonField);
        dialog.getDialogPane().setContent(dialogPane);
        ButtonType scheduleButton = new ButtonType("Schedule", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(scheduleButton, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(response -> {
            if (response == scheduleButton && datePicker.getValue() != null && timeComboBox.getValue() != null) {
                LocalDateTime dateTime = LocalDateTime.of(datePicker.getValue(), LocalTime.parse(timeComboBox.getValue()));
                boolean isScheduled = isAppointment
                        ? patientController.scheduleAppointment(patientId, dateTime, reasonField.getText())
                        : patientController.scheduleAdmission(patientId, dateTime, reasonField.getText());

                Alert alert = new Alert(isScheduled ? Alert.AlertType.INFORMATION : Alert.AlertType.ERROR,
                        isScheduled ? "Scheduled successfully!" : "Failed to schedule.");
                alert.showAndWait();
                refreshTable();
            }
        });
    }

    private void refreshTable() {
        patientData.clear();
        patientData.addAll(patientController.getAllPatients());
    }
}
