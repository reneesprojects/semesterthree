package views;

import controllers.MedicalReportController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import models.MedicalReport;

import java.time.LocalDate;

public class MedicalReportForm {

    private TableView<MedicalReport> tableView;
    private TextField patientIdField;
    private TextField reportDetailsField;
    private DatePicker reportDatePicker;
    private TextField diagnosisField;
    private Button submitButton;
    private Button editButton;
    private Button deleteButton;
    private MedicalReport selectedReport = null;

    public void display() {
        Stage stage = new Stage();
        stage.setTitle("File Medical Report");

        patientIdField = new TextField();
        reportDetailsField = new TextField();
        reportDatePicker = new DatePicker();
        diagnosisField = new TextField();

        submitButton = new Button("Submit Report");
        submitButton.setOnAction(event -> handleSubmit());

        editButton = new Button("Edit Report");
        editButton.setOnAction(event -> handleEdit());

        deleteButton = new Button("Delete Report");
        deleteButton.setOnAction(event -> handleDelete());

        GridPane formGrid = new GridPane();
        formGrid.setPadding(new Insets(10));
        formGrid.setHgap(10);
        formGrid.setVgap(10);
        formGrid.add(new Label("Patient ID:"), 0, 0);
        formGrid.add(patientIdField, 1, 0);
        formGrid.add(new Label("Report Details:"), 0, 1);
        formGrid.add(reportDetailsField, 1, 1);
        formGrid.add(new Label("Report Date:"), 0, 2);
        formGrid.add(reportDatePicker, 1, 2);
        formGrid.add(new Label("Diagnosis:"), 0, 3);
        formGrid.add(diagnosisField, 1, 3);
        formGrid.add(submitButton, 0, 4);
        formGrid.add(editButton, 1, 4);
        formGrid.add(deleteButton, 2, 4);

        tableView = new TableView<>();
        TableColumn<MedicalReport, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());

        TableColumn<MedicalReport, Integer> patientIdColumn = new TableColumn<>("Patient ID");
        patientIdColumn.setCellValueFactory(cellData -> cellData.getValue().patientIdProperty().asObject());

        TableColumn<MedicalReport, String> reportDetailsColumn = new TableColumn<>("Report Details");
        reportDetailsColumn.setCellValueFactory(cellData -> cellData.getValue().reportDetailsProperty());

        TableColumn<MedicalReport, String> reportDateColumn = new TableColumn<>("Report Date");
        reportDateColumn.setCellValueFactory(cellData -> cellData.getValue().reportDateProperty());

        TableColumn<MedicalReport, String> diagnosisColumn = new TableColumn<>("Diagnosis");
        diagnosisColumn.setCellValueFactory(cellData -> cellData.getValue().diagnosisProperty());

        tableView.getColumns().addAll(idColumn, patientIdColumn, reportDetailsColumn, reportDateColumn, diagnosisColumn);
        loadMedicalReports();

        // Handle row selection to populate fields for editing
        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedReport = newSelection;
                patientIdField.setText(String.valueOf(selectedReport.getPatientId()));
                reportDetailsField.setText(selectedReport.getReportDetails());
                reportDatePicker.setValue(LocalDate.parse(selectedReport.getReportDate()));
                diagnosisField.setText(selectedReport.getDiagnosis());
            }
        });

        VBox layout = new VBox(10, formGrid, tableView);
        layout.setPadding(new Insets(10));

        Scene scene = new Scene(layout, 700, 450);
        stage.setScene(scene);
        stage.show();
    }

    private void loadMedicalReports() {
        MedicalReportController controller = new MedicalReportController();
        ObservableList<MedicalReport> reports = FXCollections.observableArrayList(controller.getAllMedicalReports());
        tableView.setItems(reports);
    }

    private void handleSubmit() {
        try {
            int patientId = Integer.parseInt(patientIdField.getText());
            String reportDetails = reportDetailsField.getText();
            LocalDate reportDate = reportDatePicker.getValue();
            String diagnosis = diagnosisField.getText();

            MedicalReportController controller = new MedicalReportController();

            if (!controller.patientExists(patientId)) {
                System.out.println("Invalid Patient ID: Patient does not exist.");
                return;
            }

            boolean success = controller.submitMedicalReport(patientId, reportDetails, reportDate.toString(), diagnosis);
            if (success) {
                System.out.println("Medical report filed successfully!");
                loadMedicalReports();
                clearFields();
            } else {
                System.out.println("Failed to file medical report.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid Patient ID.");
        }
    }

    private void handleEdit() {
        if (selectedReport != null) {
            try {
                int patientId = Integer.parseInt(patientIdField.getText());
                String reportDetails = reportDetailsField.getText();
                LocalDate reportDate = reportDatePicker.getValue();
                String diagnosis = diagnosisField.getText();

                MedicalReportController controller = new MedicalReportController();
                boolean success = controller.updateMedicalReport(selectedReport.getId(), patientId, reportDetails, reportDate.toString(), diagnosis);

                if (success) {
                    System.out.println("Medical report updated successfully!");
                    loadMedicalReports();
                    clearFields();
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid Patient ID.");
            }
        } else {
            System.out.println("Please select a report to edit.");
        }
    }

    private void handleDelete() {
        if (selectedReport != null) {
            MedicalReportController controller = new MedicalReportController();
            boolean success = controller.deleteMedicalReport(selectedReport.getId());

            if (success) {
                System.out.println("Medical report deleted successfully!");
                loadMedicalReports();
                clearFields();
            } else {
                System.out.println("Failed to delete medical report.");
            }
        } else {
            System.out.println("Please select a report to delete.");
        }
    }

    private void clearFields() {
        patientIdField.clear();
        reportDetailsField.clear();
        reportDatePicker.setValue(null);
        diagnosisField.clear();
        selectedReport = null;
    }
}
