package views;
 
import database.DatabaseConnection;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import models.Patient;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class BedAllotmentForm {
 
    private TableView<Bed> tableView;
 
    public void display(Patient patient) {
        Stage stage = new Stage();
        stage.setTitle("Bed Allotment for " + patient.getName());
 
        // Create the TableView
        tableView = new TableView<>();
        tableView.setPrefSize(500, 350);
 
        // Define columns
        TableColumn<Bed, Integer> bedNumberColumn = new TableColumn<>("Bed Number");
        bedNumberColumn.setCellValueFactory(new PropertyValueFactory<>("bedNumber"));
 
        TableColumn<Bed, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
 
        TableColumn<Bed, Integer> patientIdColumn = new TableColumn<>("Patient ID");
        patientIdColumn.setCellValueFactory(new PropertyValueFactory<>("patientId"));
 
        TableColumn<Bed, String> patientNameColumn = new TableColumn<>("Patient Name");
        patientNameColumn.setCellValueFactory(new PropertyValueFactory<>("patientName"));
 
        // Add columns to the table
        tableView.getColumns().addAll(bedNumberColumn, statusColumn, patientIdColumn, patientNameColumn);
 
        // Populate the table with data from the database
        populateTableWithBeds();
 
        // Button to allot the selected bed to the patient
        Button allotButton = new Button("Allot Bed");
        allotButton.setOnAction(event -> allotSelectedBedToPatient(patient, stage));
 
        // Button to remove the patient from the selected bed
        Button removeButton = new Button("Remove Patient");
        removeButton.setOnAction(event -> removePatientFromBed(stage));
 
        // Layout
        BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(10));
        borderPane.setCenter(tableView);
        // Create an HBox for buttons
        javafx.scene.layout.HBox buttonBox = new javafx.scene.layout.HBox(10, allotButton, removeButton);
        borderPane.setBottom(buttonBox);
 
        Scene scene = new Scene(borderPane, 600, 400);
        stage.setScene(scene);
        stage.show();
    }
 
    // Method to populate the table with bed data from the database
    private void populateTableWithBeds() {
        tableView.getItems().clear();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Beds");
             ResultSet rs = stmt.executeQuery()) {
 
            while (rs.next()) {
                int bedNumber = rs.getInt("bed_number");
                String status = rs.getString("status");
                Integer patientId = rs.getObject("patient_id") != null ? rs.getInt("patient_id") : null;
                String patientName = rs.getString("patient_name");
 
                tableView.getItems().add(new Bed(bedNumber, status, patientId, patientName));
            }
 
        } catch (SQLException e) {
            System.out.println("Error fetching bed data from database.");
        }
    }
 
    // Method to allot the selected bed to the patient
    private void allotSelectedBedToPatient(Patient patient, Stage stage) {
        Bed selectedBed = tableView.getSelectionModel().getSelectedItem();
 
        if (selectedBed != null && "Vacant".equals(selectedBed.getStatus())) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE Beds SET status = 'Occupied', patient_id = ?, patient_name = ? WHERE bed_number = ?")) {
 
                // Update the bed in the database
                stmt.setInt(1, patient.getId());
                stmt.setString(2, patient.getName());
                stmt.setInt(3, selectedBed.getBedNumber());
 
                int rowsUpdated = stmt.executeUpdate();
                if (rowsUpdated > 0) {
                    // Update the bed details to reflect the patient's information in the UI
                    selectedBed.setStatus("Occupied");
                    selectedBed.setPatientId(patient.getId());
                    selectedBed.setPatientName(patient.getName());
 
                    tableView.refresh();
 
                    // Show success alert
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Bed " + selectedBed.getBedNumber() + " successfully allotted to " + patient.getName() + ".");
                    alert.showAndWait();
 
                    stage.close();
                } else {
                    System.out.println("Failed to allot bed.");
                }
 
            } catch (SQLException e) {
                System.out.println("Error allotting bed to patient.");
            }
        } else {
            System.out.println("Please select a vacant bed to allot.");
        }
    }
 
    // Method to remove the selected patient from the bed
    private void removePatientFromBed(Stage stage) {
        Bed selectedBed = tableView.getSelectionModel().getSelectedItem();
 
        if (selectedBed != null && "Occupied".equals(selectedBed.getStatus())) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE Beds SET status = 'Vacant', patient_id = NULL, patient_name = NULL WHERE bed_number = ?")) {
 
                // Update the bed in the database
                stmt.setInt(1, selectedBed.getBedNumber());
 
                int rowsUpdated = stmt.executeUpdate();
                if (rowsUpdated > 0) {
                    // Update the bed details to reflect the vacancy in the UI
                    selectedBed.setStatus("Vacant");
                    selectedBed.setPatientId(null);
                    selectedBed.setPatientName(null);
 
                    tableView.refresh();
 
                    // Show success alert
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Patient successfully removed from Bed " + selectedBed.getBedNumber() + ".");
                    alert.showAndWait();
 
                } else {
                    System.out.println("Failed to remove patient.");
                }
 
            } catch (SQLException e) {
                System.out.println("Error removing patient from bed.");
            }
        } else {
            System.out.println("Please select an occupied bed to remove the patient.");
        }
    }
 
    // Static nested class to represent a Bed
    public static class Bed {
        private final Integer bedNumber;
        private String status;
        private Integer patientId;
        private String patientName;
 
        public Bed(Integer bedNumber, String status, Integer patientId, String patientName) {
            this.bedNumber = bedNumber;
            this.status = status;
            this.patientId = patientId;
            this.patientName = patientName;
        }
 
        public Integer getBedNumber() {
            return bedNumber;
        }
 
        public String getStatus() {
            return status;
        }
 
        public void setStatus(String status) {
            this.status = status;
        }
 
        public Integer getPatientId() {
            return patientId;
        }
 
        public void setPatientId(Integer patientId) {
            this.patientId = patientId;
        }
 
        public String getPatientName() {
            return patientName;
        }
 
        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }
    }
}