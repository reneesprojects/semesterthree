package views;
 
import database.DatabaseConnection;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import models.Patient;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class AdmitPatient {
 
    private Patient fetchedPatient; // Holds the fetched patient information
 
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Admit Patient");
 
        // Patient Details Section
        Label patientIdLabel = new Label("Patient ID:");
        TextField patientIdField = new TextField();
        Button fetchDetailsButton = new Button("Fetch Details");
 
        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();
        nameField.setEditable(false);
 
        Label ageLabel = new Label("Age:");
        TextField ageField = new TextField();
        ageField.setEditable(false);
 
        Label genderLabel = new Label("Gender:");
        TextField genderField = new TextField();
        genderField.setEditable(false);
 
        Label contactLabel = new Label("Contact Number:");
        TextField contactField = new TextField();
        contactField.setEditable(false);
 
        Label addressLabel = new Label("Address:");
        TextField addressField = new TextField();
        addressField.setEditable(false);
 
        // GridPane for Patient Details layout
        GridPane detailsGrid = new GridPane();
        detailsGrid.setPadding(new Insets(10));
        detailsGrid.setHgap(10);
        detailsGrid.setVgap(10);
        detailsGrid.add(patientIdLabel, 0, 0);
        detailsGrid.add(patientIdField, 1, 0);
        detailsGrid.add(fetchDetailsButton, 2, 0);
        detailsGrid.add(nameLabel, 0, 1);
        detailsGrid.add(nameField, 1, 1);
        detailsGrid.add(ageLabel, 0, 2);
        detailsGrid.add(ageField, 1, 2);
        detailsGrid.add(genderLabel, 0, 3);
        detailsGrid.add(genderField, 1, 3);
        detailsGrid.add(contactLabel, 0, 4);
        detailsGrid.add(contactField, 1, 4);
        detailsGrid.add(addressLabel, 0, 5);
        detailsGrid.add(addressField, 1, 5);
 
        // Buttons for Inpatients and Outpatients
        Button admitButton = new Button("Inpatients");
        Button outpatientButton = new Button("Outpatients");
 
        // Action to fetch patient details
        fetchDetailsButton.setOnAction(e -> fetchPatientDetails(patientIdField.getText(), nameField, ageField, genderField, contactField, addressField));
 
        // Action to admit inpatient and update admission type in the database
        admitButton.setOnAction(e -> {
            if (fetchedPatient != null) {
                updateAdmissionType(fetchedPatient.getId(), "InPatient");
                BedAllotmentForm bedAllotmentForm = new BedAllotmentForm();
                bedAllotmentForm.display(fetchedPatient); // Pass the patient to BedAllotmentForm
            } else {
                showErrorAlert("No Patient Selected", "Please fetch patient details before admitting.");
            }
        });
 
        // Action to admit outpatient and update admission type in the database
        outpatientButton.setOnAction(e -> {
            if (fetchedPatient != null) {
                updateAdmissionType(fetchedPatient.getId(), "OutPatient");
                showInformationAlert("Outpatient Admitted", "The patient has been admitted as an OutPatient.");
            } else {
                showErrorAlert("No Patient Selected", "Please fetch patient details before admitting.");
            }
        });
 
        // Layout for buttons
        HBox buttonBox = new HBox(20, admitButton, outpatientButton);
        buttonBox.setPadding(new Insets(10));
 
        // Main layout
        VBox mainLayout = new VBox(20, detailsGrid, buttonBox);
        mainLayout.setPadding(new Insets(10));
 
        // Scene setup
        Scene scene = new Scene(mainLayout, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
 
    // Method to fetch and display patient details based on Patient ID
    private void fetchPatientDetails(String patientId, TextField nameField, TextField ageField, TextField genderField, TextField contactField, TextField addressField) {
        if (patientId == null || patientId.trim().isEmpty()) {
            showErrorAlert("Invalid Patient ID", "Please enter a valid Patient ID.");
            return;
        }
 
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT id, name, age, gender, contact_number, address FROM patients WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, Integer.parseInt(patientId));
 
            ResultSet resultSet = statement.executeQuery();
 
            if (resultSet.next()) {
                fetchedPatient = new Patient(
                    resultSet.getInt("id"),
                    resultSet.getString("name"),
                    resultSet.getInt("age"),
                    resultSet.getString("gender"),
                    resultSet.getString("contact_number"),
                    resultSet.getString("address")
                );
 
                nameField.setText(fetchedPatient.getName());
                ageField.setText(String.valueOf(fetchedPatient.getAge()));
                genderField.setText(fetchedPatient.getGender());
                contactField.setText(fetchedPatient.getContactNumber());
                addressField.setText(fetchedPatient.getAddress());
            } else {
                showErrorAlert("Patient Not Found", "No patient found with ID: " + patientId);
                clearFields(nameField, ageField, genderField, contactField, addressField);
                fetchedPatient = null;
            }
        } catch (SQLException e) {
            showErrorAlert("Database Error", "An error occurred while fetching patient details.");
        } catch (NumberFormatException e) {
            showErrorAlert("Invalid Input", "Patient ID must be a number.");
        }
    }
 
    // Method to update patient type in the database
    private void updateAdmissionType(int patientId, String patientType) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Use the correct column name
            String query = "UPDATE patients SET patient_type = ? WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, patientType);
            statement.setInt(2, patientId);
            statement.executeUpdate();
        } catch (SQLException e) {
            showErrorAlert("Database Error", "An error occurred while updating patient type.");
        }
    }
 
    // Utility method to clear text fields
    private void clearFields(TextField... fields) {
        for (TextField field : fields) {
            field.clear();
        }
    }
 
    // Utility method to display error alerts
    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
 
    // Utility method to display information alerts
    private void showInformationAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}