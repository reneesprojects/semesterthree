package views;

import models.Patient;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import controllers.AppointmentController;
import models.Appointment;

public class AppointmentForm {

    private Patient patient;
    private AppointmentController appointmentController = new AppointmentController();

    // Constructor to initialize with the selected Patient object
    public AppointmentForm(Patient patient) {
        this.patient = patient;
    }

    public void display() {
        Stage stage = new Stage();
        stage.setTitle("Schedule Appointment for " + patient.getName());

        // Text fields for doctor name, date, and time
        TextField doctorField = new TextField();
        TextField dateField = new TextField();
        TextField timeField = new TextField();

        // Prefill patient ID and make it read-only
        TextField patientIdField = new TextField(String.valueOf(patient.getId()));
        patientIdField.setEditable(false);

        // Button to schedule the appointment
        Button scheduleButton = new Button("Schedule Appointment");
        scheduleButton.setOnAction(event -> {
            String doctor = doctorField.getText();
            String date = dateField.getText();
            String time = timeField.getText();

            // Create a new Appointment object and save it using the controller
            Appointment appointment = new Appointment(patient.getId(), doctor, date, time);
            boolean success = appointmentController.scheduleAppointment(appointment);

            if (success) {
                System.out.println("Appointment scheduled successfully!");
                stage.close();
            } else {
                System.out.println("Failed to schedule appointment.");
            }
        });

        // Layout
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Patient ID:"), 0, 0);
        grid.add(patientIdField, 1, 0);
        grid.add(new Label("Doctor:"), 0, 1);
        grid.add(doctorField, 1, 1);
        grid.add(new Label("Date (YYYY-MM-DD):"), 0, 2);
        grid.add(dateField, 1, 2);
        grid.add(new Label("Time (HH:MM:SS):"), 0, 3);
        grid.add(timeField, 1, 3);
        grid.add(scheduleButton, 1, 4);

        Scene scene = new Scene(grid, 350, 300);
        stage.setScene(scene);
        stage.show();
    }
}

