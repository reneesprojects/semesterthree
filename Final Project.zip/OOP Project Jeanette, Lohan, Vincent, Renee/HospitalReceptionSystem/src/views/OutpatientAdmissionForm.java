package views;

import controllers.AdmissionController;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class OutpatientAdmissionForm {

    public void display() {
        Stage stage = new Stage();
        stage.setTitle("Outpatient Admission");

        TextField patientIdField = new TextField();
        TextField dateField = new TextField();

        Button registerButton = new Button("Register Outpatient");
        registerButton.setOnAction(event -> {
            try {
                int patientId = Integer.parseInt(patientIdField.getText());
                String date = dateField.getText();

                // Basic date format validation
                if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                    showAlert("Invalid Date Format", "Please enter the date in YYYY-MM-DD format.");
                    return;
                }

                boolean success = new AdmissionController().admitPatient(patientId, "Outpatient", null, date);
                if (success) {
                    System.out.println("Outpatient registered successfully!");
                    stage.close();
                } else {
                    showAlert("Registration Failed", "Unable to register outpatient. Please try again.");
                }

            } catch (NumberFormatException ex) {
                showAlert("Invalid Patient ID", "Patient ID must be a number.");
            }
        });

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Patient ID:"), 0, 0);
        grid.add(patientIdField, 1, 0);
        grid.add(new Label("Date (YYYY-MM-DD):"), 0, 1);
        grid.add(dateField, 1, 1);
        grid.add(registerButton, 1, 2);

        Scene scene = new Scene(grid, 300, 200);
        stage.setScene(scene);
        stage.show();
    }

    // Utility method to display error alerts
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

