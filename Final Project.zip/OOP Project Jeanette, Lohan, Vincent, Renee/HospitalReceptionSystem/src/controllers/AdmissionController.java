package controllers;
 
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import models.Admission;

public class AdmissionController {
    
    public boolean admitPatient(Admission admission) {
    String sql = "INSERT INTO admissions (patient_id, admission_type, room_id, date) VALUES (?, ?, ?, ?)";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, admission.getPatientId());
        stmt.setString(2, admission.getAdmissionType());
        stmt.setObject(3, admission.getRoomId()); // Use null for outpatient
        stmt.setString(4, admission.getDate());
        stmt.executeUpdate();

        return true;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


    // Method to list all admissions
    public List<Admission> getAllAdmissions() {
        List<Admission> admissions = new ArrayList<>();
        String sql = "SELECT * FROM admissions";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Admission admission = new Admission(
                    rs.getInt("patient_id"),
                    rs.getString("admission_type"),
                    (Integer) rs.getObject("room_id"),
                    rs.getString("date")
                );
                admission.setId(rs.getInt("id"));
                admissions.add(admission);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return admissions;
    }

    // Method to edit an admission
    public boolean editAdmission(Admission admission) {
        String sql = "UPDATE admissions SET patient_id = ?, admission_type = ?, room_id = ?, date = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, admission.getPatientId());
            stmt.setString(2, admission.getAdmissionType());
            stmt.setObject(3, admission.getRoomId());
            stmt.setString(4, admission.getDate());
            stmt.setInt(5, admission.getId());
            stmt.executeUpdate();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete an admission
    public boolean deleteAdmission(int admissionId) {
        String sql = "DELETE FROM admissions WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, admissionId);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean admitPatient(int patientId, String inpatient, int roomId, String date) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean admitPatient(int patientId, String outpatient, Object object, String date) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 
}
