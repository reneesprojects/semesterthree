package controllers;

import database.DatabaseConnection;
import models.MedicalReport;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicalReportController {

    public boolean submitMedicalReport(int patientId, String reportDetails, String reportDate, String diagnosis) {
        String sql = "INSERT INTO medical_reports (patient_id, report_details, report_date, diagnosis) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, patientId);
            stmt.setString(2, reportDetails);
            stmt.setString(3, reportDate);
            stmt.setString(4, diagnosis);
            stmt.executeUpdate();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateMedicalReport(int id, int patientId, String reportDetails, String reportDate, String diagnosis) {
        String sql = "UPDATE medical_reports SET patient_id = ?, report_details = ?, report_date = ?, diagnosis = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, patientId);
            stmt.setString(2, reportDetails);
            stmt.setString(3, reportDate);
            stmt.setString(4, diagnosis);
            stmt.setInt(5, id);
            stmt.executeUpdate();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteMedicalReport(int id) {
        String sql = "DELETE FROM medical_reports WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<MedicalReport> getAllMedicalReports() {
        List<MedicalReport> reports = new ArrayList<>();
        String sql = "SELECT * FROM medical_reports";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                int patientId = rs.getInt("patient_id");
                String reportDetails = rs.getString("report_details");
                String reportDate = rs.getString("report_date");
                String diagnosis = rs.getString("diagnosis");
                reports.add(new MedicalReport(id, patientId, reportDetails, reportDate, diagnosis));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reports;
    }

    public boolean patientExists(int patientId) {
        String sql = "SELECT id FROM patients WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, patientId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}





