package controllers;

import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BedAllotmentController {

    /**
     * Allot a bed to mark it as unavailable (occupied).
     * @param bedId The ID of the bed to allot.
     * @return true if the bed was successfully allotted; false otherwise.
     */
    public boolean allotBed(int bedId) {
        // SQL query to update bed availability status
        String sql = "UPDATE beds SET availability = FALSE WHERE bed_id = ? AND availability = TRUE";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bedId);  // Use the provided bedId
            return stmt.executeUpdate() > 0;  // Return true if a row was updated

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Releases a bed to mark it as available (vacant).
     * @param bedId The ID of the bed to release.
     * @return true if the bed was successfully released; false otherwise.
     */
    public boolean releaseBed(int bedId) {
        // SQL query to update bed availability status
        String sql = "UPDATE beds SET availability = TRUE WHERE bed_id = ? AND availability = FALSE";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bedId);  // Use the provided bedId
            return stmt.executeUpdate() > 0;  // Return true if a row was updated

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

