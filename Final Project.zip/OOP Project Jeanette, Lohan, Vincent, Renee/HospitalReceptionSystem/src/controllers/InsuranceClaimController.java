package controllers;
 
import database.DatabaseConnection;
import models.InsuranceClaim;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
 
public class InsuranceClaimController {
 
    public boolean submitInsuranceClaim(InsuranceClaim claim) {
        String sql = "INSERT INTO insurance_claims (patient_id, claim_amount, claim_date, description, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
 
            stmt.setInt(1, claim.getPatientId());
            stmt.setDouble(2, claim.getClaimAmount());
            stmt.setString(3, claim.getClaimDate());
            stmt.setString(4, claim.getDescription());
            stmt.setString(5, claim.getStatus());
            stmt.executeUpdate();
 
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
 
    public boolean updateInsuranceClaim(int patientId, double claimAmount, String claimDate, String description, String status, int id) {
        String sql = "UPDATE insurance_claims SET patient_id = ?, claim_amount = ?, claim_date = ?, description = ?, status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
 
            stmt.setInt(1, patientId);
            stmt.setDouble(2, claimAmount);
            stmt.setString(3, claimDate);
            stmt.setString(4, description);
            stmt.setString(5, status);
            stmt.setInt(6, id);
            stmt.executeUpdate();
 
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
 
    public boolean deleteInsuranceClaim(int id) {
        String sql = "DELETE FROM insurance_claims WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
 
            stmt.setInt(1, id);
            stmt.executeUpdate();
 
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
 
    public List<InsuranceClaim> getAllInsuranceClaims() {
        List<InsuranceClaim> claims = new ArrayList<>();
        String sql = "SELECT * FROM insurance_claims";
 
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
 
            while (rs.next()) {
                int id = rs.getInt("id");
                int patientId = rs.getInt("patient_id");
                double claimAmount = rs.getDouble("claim_amount");
                String claimDate = rs.getString("claim_date");
                String description = rs.getString("description");
                String status = rs.getString("status");
                claims.add(new InsuranceClaim(id, patientId, claimAmount, claimDate, description, status));
            }
 
        } catch (SQLException e) {
            e.printStackTrace();
        }
 
        return claims;
    }
}