package controllers;
 
import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import models.Patient;
 
public class In_Out_PatientController {
 
    // Method to admit a new patient
    public boolean admitPatient(Patient patient, String admissionType) {
        String sql = "INSERT INTO AdmitPatient (name, age, gender, contact_number, address, admission_type) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
 
            stmt.setString(1, patient.getName());
            stmt.setInt(2, patient.getAge());
            stmt.setString(3, patient.getGender());
            stmt.setString(4, patient.getContactNumber());
            stmt.setString(5, patient.getAddress());
            stmt.setString(6, admissionType); // Set admission type (InPatient or OutPatient)
            stmt.executeUpdate();
 
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
 
    // Method to get all patients
    public List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();
        String sql = "SELECT * FROM AdmitPatient";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
 
            while (rs.next()) {
                Patient patient = new Patient(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getString("gender"),
                    rs.getString("contact_number"),
                    rs.getString("address")
                );
                patients.add(patient);
            }
        } catch (SQLException e) {
        }
        return patients;
    }
 
    // Method to edit a patient record
    public boolean editPatient(Patient patient) {
        String sql = "UPDATE AdmitPatient SET name = ?, age = ?, gender = ?, contact_number = ?, address = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
 
            stmt.setString(1, patient.getName());
            stmt.setInt(2, patient.getAge());
            stmt.setString(3, patient.getGender());
            stmt.setString(4, patient.getContactNumber());
            stmt.setString(5, patient.getAddress());
            stmt.setInt(6, patient.getId());
            stmt.executeUpdate();
 
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
 
    // Method to delete a patient record
    public boolean deletePatient(int patientId) {
        String sql = "DELETE FROM AdmitPatient WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
 
            stmt.setInt(1, patientId);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}