package models;

import javafx.beans.property.*;

public class InsuranceClaim {

    private SimpleIntegerProperty id;
    private SimpleIntegerProperty patientId;
    private SimpleDoubleProperty claimAmount;
    private SimpleStringProperty claimDate;
    private SimpleStringProperty description;
    private SimpleStringProperty status;

    // Full constructor for all fields, including 'id' for existing claims
    public InsuranceClaim(int id, int patientId, double claimAmount, String claimDate, String description, String status) {
        this.id = new SimpleIntegerProperty(id);
        this.patientId = new SimpleIntegerProperty(patientId);
        this.claimAmount = new SimpleDoubleProperty(claimAmount);
        this.claimDate = new SimpleStringProperty(claimDate);
        this.description = new SimpleStringProperty(description);
        this.status = new SimpleStringProperty(status);
    }

    // Constructor without 'id' for new claims
    public InsuranceClaim(int patientId, double claimAmount, String claimDate, String description, String status) {
        this.patientId = new SimpleIntegerProperty(patientId);
        this.claimAmount = new SimpleDoubleProperty(claimAmount);
        this.claimDate = new SimpleStringProperty(claimDate);
        this.description = new SimpleStringProperty(description);
        this.status = new SimpleStringProperty(status);
    }

    // Getters and setters
    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public int getPatientId() {
        return patientId.get();
    }

    public void setPatientId(int patientId) {
        this.patientId.set(patientId);
    }

    public SimpleIntegerProperty patientIdProperty() {
        return patientId;
    }

    public double getClaimAmount() {
        return claimAmount.get();
    }

    public void setClaimAmount(double claimAmount) {
        this.claimAmount.set(claimAmount);
    }

    public SimpleDoubleProperty claimAmountProperty() {
        return claimAmount;
    }

    public String getClaimDate() {
        return claimDate.get();
    }

    public void setClaimDate(String claimDate) {
        this.claimDate.set(claimDate);
    }

    public SimpleStringProperty claimDateProperty() {
        return claimDate;
    }

    public String getDescription() {
        return description.get();
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public SimpleStringProperty descriptionProperty() {
        return description;
    }

    public String getStatus() {
        return status.get();
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public SimpleStringProperty statusProperty() {
        return status;
    }
}