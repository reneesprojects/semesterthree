package models;

import javafx.beans.property.*;

public class MedicalReport {
    private final SimpleIntegerProperty id;
    private final SimpleIntegerProperty patientId;
    private final SimpleStringProperty reportDetails;
    private final SimpleStringProperty reportDate;
    private final SimpleStringProperty diagnosis;

    public MedicalReport(int id, int patientId, String reportDetails, String reportDate, String diagnosis) {
        this.id = new SimpleIntegerProperty(id);
        this.patientId = new SimpleIntegerProperty(patientId);
        this.reportDetails = new SimpleStringProperty(reportDetails);
        this.reportDate = new SimpleStringProperty(reportDate);
        this.diagnosis = new SimpleStringProperty(diagnosis);
    }

    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public SimpleIntegerProperty patientIdProperty() {
        return patientId;
    }

    public SimpleStringProperty reportDetailsProperty() {
        return reportDetails;
    }

    public SimpleStringProperty reportDateProperty() {
        return reportDate;
    }

    public SimpleStringProperty diagnosisProperty() {
        return diagnosis;
    }

    public int getId() {
        return id.get();
    }

    public int getPatientId() {
        return patientId.get();
    }

    public String getReportDetails() {
        return reportDetails.get();
    }

    public String getReportDate() {
        return reportDate.get();
    }

    public String getDiagnosis() {
        return diagnosis.get();
    }
}


