package models;
 
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
 
public class Patient {
 
    private SimpleIntegerProperty id;
    private SimpleStringProperty name;
    private SimpleIntegerProperty age;
    private SimpleStringProperty gender;
    private SimpleStringProperty contactNumber;
    private SimpleStringProperty address;
 
    // Update constructor with the new field name
    public Patient(int id, String name, int age, String gender, String contactNumber, String address) {
        this.id = new SimpleIntegerProperty(id);
        this.name = new SimpleStringProperty(name);
        this.age = new SimpleIntegerProperty(age);
        this.gender = new SimpleStringProperty(gender);
        this.contactNumber = new SimpleStringProperty(contactNumber);
        this.address = new SimpleStringProperty(address);
    }
 
    // Constructor without ID for registration
    public Patient(String name, int age, String gender, String contactNumber, String address) {
        this.name = new SimpleStringProperty(name);
        this.age = new SimpleIntegerProperty(age);
        this.gender = new SimpleStringProperty(gender);
        this.contactNumber = new SimpleStringProperty(contactNumber);
        this.address = new SimpleStringProperty(address);
    }
 
    // Property Getters for TableView
    public SimpleIntegerProperty idProperty() {
        return id;
    }
 
    public SimpleStringProperty nameProperty() {
        return name;
    }
 
    public SimpleIntegerProperty ageProperty() {
        return age;
    }
 
    public SimpleStringProperty genderProperty() {
        return gender;
    }
 
    public SimpleStringProperty contactNumberProperty() {
        return contactNumber;
    }
 
    public SimpleStringProperty addressProperty() {
        return address;
    }
 
    // Regular Getters and Setters
    public int getId() {
        return id != null ? id.get() : 0; // Return 0 if ID is not set
    }
 
    public void setId(int id) {
        this.id = new SimpleIntegerProperty(id);
    }
 
    public String getName() {
        return name.get();
    }
 
    public void setName(String name) {
        this.name.set(name);
    }
 
    public int getAge() {
        return age.get();
    }
 
    public void setAge(int age) {
        this.age.set(age);
    }
 
    public String getGender() {
        return gender.get();
    }
 
    public void setGender(String gender) {
        this.gender.set(gender);
    }
 
    public String getContactNumber() {
        return contactNumber.get();
    }
 
    public void setContactNumber(String contactNumber) {
        this.contactNumber.set(contactNumber);
    }
 
    public String getAddress() {
        return address.get();
    }
 
    public void setAddress(String address) {
        this.address.set(address);
    }
 
    public int getRoomId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 
    public String getAdmissionDate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 
    public String getAdmissionType() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 
    public int getAdmissionId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
 