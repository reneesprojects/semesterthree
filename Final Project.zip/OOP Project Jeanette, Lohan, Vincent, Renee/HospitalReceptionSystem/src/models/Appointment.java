package models;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;

public class Appointment {
    private final IntegerProperty id;
    private final IntegerProperty patientId;
    private final StringProperty doctor;
    private final StringProperty date;
    private final StringProperty time;

    // Constructor to initialize with raw values
    public Appointment(int patientId, String doctor, String date, String time) {
        this.patientId = new SimpleIntegerProperty(patientId);
        this.doctor = new SimpleStringProperty(doctor);
        this.date = new SimpleStringProperty(date);
        this.time = new SimpleStringProperty(time);
        this.id = new SimpleIntegerProperty();
    }

    // Getters and setters for id
    public int getId() { return id.get(); }
    public void setId(int id) { this.id.set(id); }
    public IntegerProperty idProperty() { return id; }

    // Getters and setters for patientId
    public int getPatientId() { return patientId.get(); }
    public void setPatientId(int patientId) { this.patientId.set(patientId); }
    public IntegerProperty patientIdProperty() { return patientId; }

    // Getters and setters for doctor
    public String getDoctor() { return doctor.get(); }
    public void setDoctor(String doctor) { this.doctor.set(doctor); }
    public StringProperty doctorProperty() { return doctor; }

    // Getters and setters for date
    public String getDate() { return date.get(); }
    public void setDate(String date) { this.date.set(date); }
    public StringProperty dateProperty() { return date; }

    // Getters and setters for time
    public String getTime() { return time.get(); }
    public void setTime(String time) { this.time.set(time); }
    public StringProperty timeProperty() { return time; }
}


