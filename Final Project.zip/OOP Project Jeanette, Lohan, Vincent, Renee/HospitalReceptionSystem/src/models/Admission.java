/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author Lohan
 */
public class Admission {
    private int id;
    private int patientId;
    private String admissionType;
    private Integer roomId; // Use Integer if roomId can be null
    private String date;

    // Constructor with parameters
    public Admission(int patientId, String admissionType, Integer roomId, String date) {
        this.patientId = patientId;
        this.admissionType = admissionType;
        this.roomId = roomId;
        this.date = date;
    }

    // Getters and setters for each field
    public int getPatientId() {
        return patientId;
    }

    public String getAdmissionType() {
        return admissionType;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public String getDate() {
        return date;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}

